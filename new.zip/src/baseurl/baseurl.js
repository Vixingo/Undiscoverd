// export const BASE_URL="http://127.0.0.1:5000"
// export const BASE_URL="https://dawar.vercel.app"
// export const BASE_URL = 'http://localhost:5000';
// export const BASE_URL = "http://192.168.1.54:5000";
// export const BASE_URL = "http://192.168.243.127:5000";
export const BASE_URL = "https://aminsofttech.co/undiscoverd";
// export const BASE_URL = "https://backend-undiscovered.vercel.app";
